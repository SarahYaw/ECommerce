import { Button } from "@material-ui/core";
import { useEffect, useState } from "react";

function OrderSubmit({checkout, shippingInfo, paymentMethod, handlePlaceOrder}) {

    var paySet=Object.keys(paymentMethod).length!==0;
    var shipSet=Object.keys(shippingInfo).length!==0;

    const [toggleSubmit, setToggleSubmit] = useState();
    useEffect (()=> {
        if(shipSet && paySet){setToggleSubmit(true);}
        else {setToggleSubmit(false);}
    },[shipSet, paySet]);
    //console.log(shipSet , paySet , toggleSubmit);
    
    if(toggleSubmit) { return( <Button onClick={(event)=>{handlePlaceOrder(checkout, shippingInfo, paymentMethod)}} disabled={false}>Submit</Button> ); }
    else { return( <Button disabled={true}>Submit</Button> ); }
}

export default OrderSubmit;

