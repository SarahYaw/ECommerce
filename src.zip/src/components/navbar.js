import { AppBar, Toolbar, Typography, IconButton, Badge, Button } from "@material-ui/core";
import StoreIcon from '@material-ui/icons/Store';
import ShoppingCartOutlinedIcon from '@material-ui/icons/ShoppingCartOutlined';
//import { commerce } from "../lib/commerce";

function NavBar({cartItems, isLogged}) {

    const navBar = {
      backgroundColor:"#98ABC8",
      width:"103%",
      margin:"-1%",
      color:"white",
    }
    return(
      <AppBar position="static" style={navBar}>
      <Toolbar>
        <IconButton href="/"><StoreIcon></StoreIcon></IconButton>
        <Typography>Welcome to For Fun by Sarah</Typography>
        <IconButton href="/cart"><Badge badgeContent={cartItems} color="primary"><ShoppingCartOutlinedIcon /></Badge></IconButton>
        <Button href="/login">Log In</Button>
      </Toolbar>
    </AppBar>
    );
}

export default NavBar;