import { useState, useEffect } from "react";
import { Grid } from "@material-ui/core";
import { commerce } from "../lib/commerce";
import { useParams } from "react-router";

function Home ({setIsLogged}) {
    console.log("home.js");

    let { userToken } = useParams();
    //console.log("tkn",userToken);
    const [customerID, setCustomerID] = useState();
    const [customer, setCustomer] = useState();
    useEffect (() => {
        commerce.customer.getToken(userToken).then(
            (jwt) => {
            //console.log("jwt",jwt)
            setCustomerID(jwt["customer_id"]);
            //setUserToken(userToken);
            setIsLogged(true);
        });
    }, [userToken, setIsLogged]);
    useEffect (() => {
        commerce.customer.about().then((customer) => {
            //console.log(customer["email"]);
            setCustomer(customer);
        });
    },[customerID]);
 
    //if(commerce.customer.isLoggedIn()){
    //    <Redirect href/>
    //}
    if (!customer) { 
        return(
        <Grid container direction="column">
            <Grid item>Loading . . .</Grid>
        </Grid>);}
    else {
        return(
         <Grid container direction="column">
            <Grid item>Welcome, {customer["email"]}!</Grid>
        </Grid>);
    }
}
export default Home;