import {  Button, TextField, Grid } from "@material-ui/core";
import { useState, useEffect } from "react";
import ReactPhoneInput from 'react-phone-input-material-ui';
import { commerce } from "../lib/commerce";

function Profile({cartItems}) {
    var flag = commerce.customer.isLoggedIn();
    var fname, lname, nme;
    const [customer, setCustomer]=useState();
    useEffect (() => {
        if(flag) {
            commerce.customer.about().then((cust) => {setCustomer(cust);});
        }

    },[flag]);


    const [name, setName] = useState("");
        const [nameError, setNameError] = useState(false);
        const [nameHelper, setNameHelper] = useState("");
        const onNameFieldChange =(e) => {setName(e.target.value)}
        const onNameUnfocused =()=> {
            if (!name) {setNameError(true); setNameHelper("Please Enter your Name")} 
            else {setNameError(false); setNameHelper(""); nme=name.split(" "); fname=nme[0]; lname=nme[1]; console.log(fname,lname)} }
        
        const [phono, setPhono] = useState("");
        const [phoneError, setPhoneError] = useState(false);
        const [phoneHelper, setPhoneHelper] = useState("");
        const onPhoneFieldChange =(number) => {setPhono(number)}
        const onPhoneUnfocused =()=> {
            if (phono.length !== 11) {setPhoneError(true); setPhoneHelper("Please Enter your Phone number")} 
            else {setPhoneError(false); setPhoneHelper("")} }
        
        const [email, setemail] = useState("");
        useEffect (()=>{
            if(customer !== undefined){
                setemail(customer.email);
                setPhono(customer.phone);
                setName(customer.firstname+" "+customer.lastname);
                //console.log(customer.phone);
            }
        }, [customer])
        
        if(customer !== undefined){
        return(
            <Grid container direction="column">
                <Grid item><header>User Profile:</header></Grid>

                <Grid item><TextField name="name" label="Your Name: " onChange={onNameFieldChange} error={nameError} helperText={nameHelper} onBlur={onNameUnfocused} style={{width:"180px"}} value={name}/></Grid>
                <Grid item><ReactPhoneInput component={TextField} onChange={onPhoneFieldChange} value={phono}
                    inputProps={ {error:phoneError, helperText:phoneHelper, onBlur:onPhoneUnfocused} } style={{width:"180px", marginLeft:"-6px", marginBottom:"-50px"}}/></Grid>            
                <Grid item><TextField name="email" label="Your E-Mail address: " disabled={true} value={email} style={{width:"180px"}}/></Grid>
                <Grid item><Button onClick={()=>{commerce.customer.update({"phone":phono, "firstname":fname, "lastname":lname})}}>Submit</Button></Grid>
            </Grid>
        );
        } else{return(<header>Loading . . .</header>)}
}

export default Profile;