import { Grid } from "@material-ui/core";
import { commerce } from "../lib/commerce";
import { Redirect } from "react-router";

function LoggedOut () {
    console.log("loggedout.js");

    if (commerce.customer.isLoggedIn()) { 
        commerce.customer.logout()
        return(
        <Grid container direction="column">
            <Grid item>Logging Out . . .</Grid>
        </Grid>);}
    else {
        return(
         <Grid container direction="column">
            <Redirect to="/"/>
        </Grid>);
    }
}
export default LoggedOut;