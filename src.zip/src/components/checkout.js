import { commerce } from '../lib/commerce';
import { useEffect, useState } from "react";
import ShippingForm from './shippingform';
import Payment from './payment.js';
import OrderSubmit from './ordersubmit.js';
import { Grid } from "@material-ui/core";

function Checkout ({cart}) {
    console.log("checkout.js");

    const [orderPlaced, setOrderPlaced] = useState(false);

    const [checkout, setcheckout] = useState([]);
    useEffect( () => {
        if(cart.id !== undefined) {
        commerce.checkout.generateToken(cart.id, {"type": "cart"}).then(
        response => {setcheckout(response);}) } }, [cart]); 
    
    const [shippingInfo, setShippingInfo] = useState({});
    const [paymentMethod, setPaymentMethod] = useState({});
    const handlePlaceOrder =(checkout, shippingInfo, paymentMethod) => { 
        const orderData = {
            "line_items": checkout.live.line_items,
            "customer" : {
                "email": shippingInfo["email"]
            },
            "shipping": {
                "name": shippingInfo["name"],
                "street": shippingInfo["st"],
                "town_city": shippingInfo["city"],
                "county_state": shippingInfo["region"],
                "postal_zip_code": shippingInfo["zip"],
                "country": shippingInfo["country"]
            },
            "fulfillment": {
                "shipping_method": shippingInfo["shippingMethod"],
            },
            "payment": {
                "gateway": 'stripe',
                "stripe": {
                    "payment_method_id": paymentMethod["id"]
                }
            }
    
            };
            setOrderPlaced(true);
            commerce.checkout.capture(checkout.id, orderData).then((response) => {console.log(response)});
            
        };

        //console.log("op",orderPlaced);
    if(!orderPlaced){
    return(
        <main>
            {checkout === undefined && <p>Loading . . .</p>}
            <Grid container direction="column">
                <Grid item><br/><br/><header>Checkout</header></Grid>
                <Grid item><ShippingForm checkoutID={checkout.id} setShippingInfo={setShippingInfo}/></Grid>
                <Grid item><Payment setPaymentMethod={setPaymentMethod}/></Grid>
                <Grid item><OrderSubmit checkout={checkout} shippingInfo={shippingInfo} paymentMethod={paymentMethod} handlePlaceOrder={handlePlaceOrder}/></Grid>
            </Grid>
        </main>
    );}
    else {
        return(
        <Grid container direction="column">
            <Grid item><br/><br/><header>Order placed. Thank you!</header></Grid>
        </Grid>);
    }
}
export default Checkout;