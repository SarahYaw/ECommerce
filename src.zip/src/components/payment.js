import { Button } from "@material-ui/core";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, ElementsConsumer, CardElement } from "@stripe/react-stripe-js";

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLIC_KEY);

function Payment ({setPaymentMethod}) {

    const handleCardSubmit = (event, stripe, elements) => {
        event.preventDefault();
        const cardElement = elements.getElement(CardElement);
        stripe.createPaymentMethod({type:"card", card:cardElement}).then(({error, paymentMethod}) => {if(error){console.log(error)}else{setPaymentMethod(paymentMethod)}})
    }

    return (
        <Elements stripe={stripePromise}>
            <ElementsConsumer>
                {
                    ({stripe, elements}) => (
                        <form onSubmit={(event) => handleCardSubmit(event, stripe, elements)}>
                            <CardElement />
                            <Button type="submit">Submit Card Payment</Button>
                        </form>
                    )
                }
            </ElementsConsumer>
        </Elements>
    );
}
export default Payment;