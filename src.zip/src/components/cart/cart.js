import { Grid,Button } from "@material-ui/core";
import CartItem from "./cartItem.js";

function Cart({cart, eptyCrt, rmvCrt, decQty, incQty}) {

    if (!cart || !cart.line_items) {return<div>Loading...</div>}
    if (cart.total_items===0) {return<div>Your Cart is empty</div>}
    console.log(cart);
    return(
        <Grid container direction="column">
            {
                cart.line_items.map((cartItem) => {
                        return (
                            <CartItem key={cartItem.id} cartItem={cartItem} rmvCrt={rmvCrt} decQty={decQty} incQty={incQty}/>
                        );
                    }
                )
            }
            <Grid item>
                <Button onClick={() =>{eptyCrt()}}>Empty Cart</Button> 
                <Button href="/checkout">Check Out</Button> 
            </Grid>
        </Grid>
    );
}
export default Cart;