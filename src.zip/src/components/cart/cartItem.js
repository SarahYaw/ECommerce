import { Button, Grid } from "@material-ui/core";

function CartItem({cartItem, rmvCrt, decQty, incQty}) {

    const imgStyle ={
        height:"200px",
        width:"200px",
        objectFit:"cover",
        display:"block",
        margin:"auto",
    }



    return(
        <Grid item container style={{backgroundColor:"#DADFDF", margin:"1%", width:"98%"}}>
            <Grid item xs={12} sm={4}><div><img src={cartItem.image.url} alt={cartItem.name} style={imgStyle}></img></div></Grid>
            <Grid item xs={12} sm={6}container direction="column">
                <Grid item>{cartItem.name}</Grid>
                <Grid item> 
                    <Button onClick={() =>{decQty(cartItem)}}>-</Button>
                    Qty: {cartItem.quantity} 
                    <Button onClick={() =>{incQty(cartItem)}}>+</Button> 
                    <Button onClick={() =>{rmvCrt(cartItem)}}>Remove</Button> 
                </Grid>
            </Grid>
            <Grid item xs={12} sm={2}>${cartItem.line_total.formatted}</Grid>
        </Grid>
    )
}
export default CartItem;