import { MenuItem, Select, Button, TextField, Grid } from "@material-ui/core";
import { useState, useEffect } from "react";
import ReactPhoneInput from 'react-phone-input-material-ui';
import { commerce } from "../lib/commerce";

function ShippingForm ({checkoutID, setShippingInfo}) {
    var flag = commerce.customer.isLoggedIn();
    const [customer, setCustomer]=useState();
    useEffect (() => {
        if(flag) {
            commerce.customer.about().then((cust) => {
                setCustomer(cust);
                setName(cust.firstname+" "+cust.lastname);
                setPhono(cust.phone);
                setemail(cust.email);});
        }
    },[flag]);

    const [country, setcountry] = useState("");
    const [countries, setcountries] = useState(undefined);
    useEffect (()=>{
        if(checkoutID !== undefined) {
        commerce.services.localeListShippingCountries(checkoutID).then(
            (response)=> {
                setcountries(response["countries"]); 
                setcountry(Object.keys(response["countries"])[0]) } ) }
    }, [checkoutID])
    const [region, setRegion] = useState("");
    const [regions, setRegions] = useState("");
    useEffect (()=>{
        if(country){
        commerce.services.localeListShippingSubdivisions(checkoutID, country).then((response)=> {setRegions(response["subdivisions"]); setRegion(Object.keys(response["subdivisions"])[0]) } )}
    }, [checkoutID, country])
    const [shippingMethod, setShippingMethod] = useState("");
    const [shippingMethods, setShippingMethods] = useState("");
    useEffect (()=>{
        if(country && region){
        commerce.checkout.getShippingOptions(checkoutID, {"country":country,"region":region}).then((response)=> {setShippingMethods(response); setShippingMethod(response[0]["id"]) } ) }
    }, [checkoutID, country, region])
    const [name, setName] = useState("");
        const [nameError, setNameError] = useState(false);
        const [nameHelper, setNameHelper] = useState("");
        const onNameFieldChange =(e) => {setName(e.target.value)}
        const onNameUnfocused =()=> {
            if (!name) {setNameError(true); setNameHelper("Please Enter your Name")} 
            else {setNameError(false); setNameHelper("")} }
    const [phono, setPhono] = useState("");
        const [phoneError, setPhoneError] = useState(false);
        const [phoneHelper, setPhoneHelper] = useState("");
        const onPhoneFieldChange =(number) => {setPhono(number)}
        const onPhoneUnfocused =()=> {
             if (phono.length !== 11) {setPhoneError(true); setPhoneHelper("Please Enter your Phone number")} 
             else {setPhoneError(false); setPhoneHelper("")} }
    const [st, setSt] = useState("");
        const [stError, setStError] = useState(false);
        const [stHelper, setStHelper] = useState("");
        const onStFieldChange =(e) => {setSt(e.target.value)}
        const onStUnfocused =()=> {
            if (!st) {setStError(true); setStHelper("Please Enter your Street Address")} 
            else {setStError(false); setStHelper("")} }
    const [city, setCity] = useState("");
        const [cityError, setCityError] = useState(false);
        const [cityHelper, setCityHelper] = useState("");
        const onCityFieldChange =(e) => {setCity(e.target.value)}
        const onCityUnfocused =()=> {
            if (!st) {setCityError(true); setCityHelper("Please Enter your City")} 
            else {setCityError(false); setCityHelper("")} }
    const [zip, setZip] = useState("");
        const [zipError, setZipError] = useState(false);
        const [zipHelper, setZipHelper] = useState("");
        const onZipFieldChange =(e) => {setZip(e.target.value)}
        const onZipUnfocused =()=> {
            if (!st) {setZipError(true); setZipHelper("Please Enter your Zip Code")} 
            else {setZipError(false); setZipHelper("")} }
    const [email, setemail] = useState("");
        const [emailError, setEmailError] = useState(false);
        const [emailHelper, setEmailHelper] = useState("");
        const onEmailFieldChange =(e) => {setemail(e.target.value);}
        const onEmailUnfocused =()=> {
            if (!email) {setEmailError(true); setEmailHelper("Please Enter your E-Mail")} 
            else {setEmailError(false); setEmailHelper("") } }

    const ifLoggedIn=() => {
        if(customer !== undefined) {
            return(<>
                <Grid item><TextField name="name"  size="small" disabled={true} value={name} onChange={onNameFieldChange}/></Grid>
                <Grid item><ReactPhoneInput component={TextField}  disabled={true} style={{width:"180px", marginLeft:"-6px", marginBottom:"-50px"}} value={phono} onChange={onPhoneFieldChange} /></Grid>
                <Grid item><TextField name="email"  disabled={true} value={email} onChange={onEmailFieldChange}/></Grid>
            </>);
        }
        else {
            return(<>
                <Grid item><TextField name="name" label="Your Name: " onChange={onNameFieldChange} error={nameError} helperText={nameHelper} onBlur={onNameUnfocused}/></Grid>
                <Grid item><ReactPhoneInput component={TextField} onChange={onPhoneFieldChange} 
                    inputProps={ {error:phoneError, helperText:phoneHelper, onBlur:onPhoneUnfocused} } style={{width:"180px", marginLeft:"-6px", marginBottom:"-50px"}}/></Grid>
                <Grid item><TextField name="email" label="Your E-Mail address: " onChange={onEmailFieldChange} error={emailError} helperText={emailHelper} onBlur={onEmailUnfocused}/></Grid>
            </>);
        }
    }
    return (
        <Grid container direction="column">
            <Grid item><h3>Please fill out your shipping information</h3></Grid>
            {ifLoggedIn()}
            
            {countries && country &&  <Grid item><Select value={country} onChange={(e) => {setcountry(e.target.value)}}>
                { Object.keys(countries).map((countryCode)=> { return (<MenuItem value={countryCode} key={countryCode}>{countries[countryCode]}</MenuItem>); })   }
            </Select></Grid>}
            
            {regions && region &&  <Grid item><Select value={region} onChange={(e) => {setRegion(e.target.value)}}>
                { Object.keys(regions).map((regionCode)=> { return (<MenuItem value={regionCode} key={regionCode}>{regions[regionCode]}</MenuItem>); })   }
            </Select></Grid>}
            
            {shippingMethods && shippingMethod &&  <Grid item><Select value={shippingMethod} onChange={(e) => {setShippingMethod(e.target.value)}}>
                { shippingMethods.map((shippingCode)=> { return (<MenuItem value={shippingCode["id"]} key={shippingCode["id"]}>{shippingCode["description"]}</MenuItem>); })   }
            </Select></Grid>}
            
            <Grid item><TextField name="st" label="Your Street Address: " onChange={onStFieldChange} error={stError} helperText={stHelper} onBlur={onStUnfocused}/></Grid>
            <Grid item><TextField name="city" label="Your City: " onChange={onCityFieldChange} error={cityError} helperText={cityHelper} onBlur={onCityUnfocused}/></Grid>
            <Grid item><TextField name="zip" label="Your Zip Code: " onChange={onZipFieldChange} error={zipError} helperText={zipHelper} onBlur={onZipUnfocused}/></Grid>
            <Grid item><Button onClick={()=>{setShippingInfo(
                {
                    "country":country, 
                    "region":region, 
                    "shippingMethod":shippingMethod, 
                    "name":name, 
                    "phone":phono, 
                    "st":st, 
                    "city":city, 
                    "zip":zip, 
                    "email":email})}}>Confirm Shipping Address</Button></Grid>
        </Grid>
    );
}
export default ShippingForm;