import { useEffect, useState } from "react"
import { commerce } from "../../lib/commerce";
import { Card, CardActionArea, CardMedia, Grid } from "@material-ui/core";

function Products() {
    console.log("products.js");
    const [products, setProducts] = useState([]);
    useEffect( () => {
        commerce.products.list().then(result => {
            setProducts(result.data);
        });
    },[]);

    const cardStyle ={
        height:"300px",
    }

    return(
        <main style={{width:"75%", margin:"auto"}}>
            {products.length === 0 && <p>Loading . . .</p>}
            <Grid container direction="row">
            { 
                products.map((product) => {
                    return (
                        <Grid item xs={12} sm={6} md={4} lg={3} key={product.id}>
                            <Card><CardActionArea href={"/products/"+product.id}>
                                <CardMedia image ={product.image.url} alt={product.name} style={cardStyle} />
                            </CardActionArea></Card>
                        </Grid> 
                    );
                })
            }
            </Grid>
        </main>
    );

}

export default Products;