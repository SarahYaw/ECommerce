import { useParams } from "react-router-dom"
import { useEffect, useState, React } from "react";
import { commerce } from "../../lib/commerce";
import { Button, Grid } from "@material-ui/core";
import "react-image-gallery/styles/css/image-gallery.css"
import ImageGallery from 'react-image-gallery';
import prods from "../../prods.js";


function Product({handleAddToCart}) {
    console.log("product.js");
    
    let { productID } = useParams();
    var [product, setProduct] = useState(undefined);
    useEffect( () => {
        commerce.products.retrieve(productID)
        .then((response) => { 
            setProduct(response);
        })
    }, [productID]);

    var images;
    if(product !== undefined){images=( (prods().filter((element)=>element.name === product.name))[0].pictures );}
    
    var path = "/pictures/";
    //console.log(path);
    
    return(
        <main>
            {product !== undefined && 
            <Grid container direction="row">
                <Grid item xs={12} md={4}>
                   <ImageGallery 
                       items= {images.map((output)=>{
                           //console.log(path+output); 
                           return{original: path+output}})} showPlayButton={false}/>
                </Grid>
                <Grid item xs={12} md={4}>
                    <h2>{product.name}</h2>
                    <h3>${product.price.formatted}</h3>
                    <Button onClick={
                        () =>{handleAddToCart(product.id, 1)}}>
                        Add to Cart</Button>
                    <div dangerouslySetInnerHTML={{ __html: product.description}} />
                </Grid>
            </Grid>
            }
        </main>
    );
}
export default Product;