import './../App.css';
import { useState, useEffect } from "react";
import { commerce } from "../lib/commerce";
import { Card, Grid, CardHeader, CardContent } from "@material-ui/core";


function Orders () {
    console.log("orders.js");
    var flag = commerce.customer.isLoggedIn();
    
    const [orders, setOrders] = useState([]);
    useEffect( () => {
        if(flag){
        commerce.customer.getOrders().then(result => {
            setOrders(result.data);
            //console.log(result.data);
            
        });}
    },[flag]);
    if(commerce.customer.isLoggedIn()){
        return(
            <main style={{width:"75%", margin:"auto"}}>
                {!orders && <p>Loading . . .</p>}
                <Grid container direction="row">
                { 
                orders.map((order) => {
                    var timestamp = order.created;
                    var date = new Date(timestamp * 1000);
                    //console.log(date);
                    return (
                        <Grid item key={order.id}>
                            <Card style={{border:"0px", padding:"0px", width:"70vw"}}>
                            <CardHeader style={{backgroundColor:"#DADFDF"}}
                                title={<div>Order Placed: {date.getMonth()}/{date.getDate()}/{date.getFullYear()}</div>}
                                subheader={<div>{order.order.total.formatted_with_symbol}</div>}/>
                            <CardContent>
                                <Grid item container direction="column">
                                    <table>
                                        <tbody>
                                        {
                                            order.order.line_items.map((item) => {
                                                return(
                                                <tr key={item.id}>
                                                    <td style={{width:"63%"}}>{item.product_name}</td>
                                                    <td style={{width:"23%"}}>{item.quantity}</td> 
                                                    <td style={{width:"13%", textAlign:"Right"}}>{item.line_total.formatted_with_symbol} USD</td>
                                                </tr>
                                                );
                                            }) 
                                        }
                                        </tbody>
                                    </table>
                                </Grid>
                            </CardContent>
                            </Card>
                        </Grid> 
                    );
                })  
                }
                </Grid>
            </main>
        );
    }
    else {
        return(<header><br/><br/>You are not logged in. <br/>You must be logged in to view order history.</header>);
    }
}
export default Orders;