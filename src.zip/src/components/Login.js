import { useState } from "react";
import { Grid,TextField, Button } from "@material-ui/core";
import { commerce } from "../lib/commerce";

function Login ({setIsLogged}) {
    console.log("login.js");

    const [temp, setTemp] = useState("");
    const [email, setEmail] = useState("");
    const [emailError, setEmailError] = useState(false);
    const [emailHelper, setEmailHelper] = useState("");
    const onEmailFieldChange =(e) => {
        setTemp(e.target.value)}
    const onEmailUnfocused =()=> {
        if (!temp) {setEmailError(true); 
            setEmailHelper("Please Enter your E-Mail")} 
        else {setEmailError(false); setEmailHelper("")} }

    if (!email) { 
        return(
        <Grid container direction="column">
            <Grid item>Please enter your email address below. You will be sent an email to confirm your log in at that address.</Grid>
            <Grid item><TextField name="email" label="Your E-Mail address: " onChange={onEmailFieldChange} error={emailError} helperText={emailHelper} onBlur={onEmailUnfocused}/></Grid>
            <Grid item><Button onClick={() => {
                if(temp)  { commerce.customer.login(temp, window.location.href+'/home').then(
                                (response) => {
                                    setEmail(response["email"]); 
                                    console.log(response);
                                    //setIsLogged(true);
                            })}}}>Submit</Button></Grid>
        </Grid>);}
    else {
        return(
        <Grid container direction="column">
            <Grid item>Email sent to {email}!</Grid>
        </Grid>);
    }
}
export default Login;