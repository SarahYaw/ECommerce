import { AppBar, Toolbar, Typography, IconButton, Badge, Button } from "@material-ui/core";
import StoreIcon from '@material-ui/icons/Store';
import ShoppingCartOutlinedIcon from '@material-ui/icons/ShoppingCartOutlined';
import PersonIcon from '@material-ui/icons/Person';

function NavLoggedIn({cartItems}) {

    const navBar = {
      backgroundColor:"#98ABC8",
      width:"103%",
      margin:"-1%",
      color:"white",
    }

      return(
        <AppBar position="static" style={navBar}>
        <Toolbar>
          <IconButton href="/"><StoreIcon/></IconButton>
          <Typography>Welcome to For Fun by Sarah</Typography>
          <IconButton href="/cart"><Badge badgeContent={cartItems} color="primary"><ShoppingCartOutlinedIcon /></Badge></IconButton>
          <Button href="/loggedout">Log Out</Button>
          <IconButton href="/profile"><PersonIcon/></IconButton>
          <Button href="/orders">Orders</Button>
        </Toolbar>
      </AppBar>);
}

export default NavLoggedIn;