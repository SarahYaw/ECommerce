import './App.css';
import Products from './components/products/products.js';
import Product from './components/products/product.js';
import NavBar from './components/navbar.js';
import NavLoggedIn from './components/navLoggedIn.js';
import Cart from './components/cart/cart.js';
import Checkout from './components/checkout.js';
import Login from './components/Login.js';
import LoggedOut from './components/loggedout.js';
import Home from './components/home.js';
import Orders from './components/orders.js';
import Profile from './components/profile.js';
import { BrowserRouter, Route } from 'react-router-dom';
import { useState } from 'react';
import { useEffect } from 'react';
import { commerce } from './lib/commerce';
import { Grid } from "@material-ui/core";

function App() {

  //const [user, setUser] = useState();
  const [isLogged, setIsLogged] = useState(false);
  useEffect (()=> {
    setIsLogged(commerce.customer.isLoggedIn());
  },[])
  //console.log("app",isLogged);
  //console.log("com",commerce.customer.isLoggedIn());
  //console.log("aut",userToken);


  const [cart, setCart]=useState({});
  useEffect(()=>{ commerce.cart.retrieve().then(
    (response) => {setCart(response)}
  )},[]);

  const handleAddToCart = (productID, quantity) => {
    commerce.cart.add(productID, quantity).then(
      (response)=>{setCart(response.cart)}
    )
  }

  const incQty = (cartItem) => {
    commerce.cart.update(cartItem.id, {quantity:(cartItem.quantity+1)}).then(
      (response)=>{setCart(response.cart)});
  }
  const decQty = (cartItem) => {
    commerce.cart.update(cartItem.id, {quantity:(cartItem.quantity-1)}).then(
      (response)=>{setCart(response.cart)});
  }
  const rmvCrt = (cartItem) => {
    commerce.cart.remove(cartItem.id).then(
      (response)=>{setCart(response.cart)});
  }
  const eptyCrt = () => {
    commerce.cart.empty().then(
      (response)=>{setCart(response.cart)});
  }

  const navDecision =()=> {
    if(isLogged===true){return(<header><NavLoggedIn cartItems={cart.total_items}/></header>);}
    else {return(<header><NavBar cartItems={cart.total_items}/></header>);}
  }

  return (
    <div className="App">
      <Grid item xs={false} sm={1} md={2}></Grid>
      <Grid container direction="column">
        {
            navDecision()
        }
        <BrowserRouter>
          <Route exact path="/" component={Products}/>
          <Route exact path="/products/:productID"><Product handleAddToCart={handleAddToCart}/></Route>
          <Route exact path="/cart"><Cart cart={cart} eptyCrt={eptyCrt} rmvCrt={rmvCrt} decQty={decQty} incQty={incQty}/></Route>
          <Route exact path="/checkout"><Checkout cart={cart}/></Route>
          <Route exact path="/login"><Login setIsLogged={setIsLogged}/></Route>   
          <Route path="/login/home/:userToken"><Home setIsLogged={setIsLogged} /></Route>
          <Route exact path="/loggedout"><LoggedOut/></Route>  
          <Route exact path="/orders"><Orders/></Route>     
          <Route exact path="/profile"><Profile/></Route>    
        </BrowserRouter>
        
      </Grid>
      <Grid item xs={false} sm={1} md={2}></Grid>
    </div>
  );
}

export default App;