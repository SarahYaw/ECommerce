function prods() {
    return [
        {
            "name": "Handspun Yarn",
            "pictures": [
                "handspun.png"
            ]
        },
        {
           "name":"Lavender Frog Sachet",
           "pictures":[
                "frogs.jpeg"
            ]
        },
        {
           "name":"Tetris Quilt",
           "pictures":[
                "tetris_quilt.jpeg"
           ]
        },
        {
            "name": "Kieth Haring Dog Embroidery",
            "pictures":[
                "keith_dog.jpeg"
            ]
        },
        {
            "name": "wildflower Hat",
            "pictures":[
                "hat_1.jpeg",
                "hat_2.jpeg"
            ]
        },
        {
            "name": "Legend of Zelda Inspired Dice Bag",
            "pictures": [
                "dice_bag.jpeg"
            ]
        },
        {
            "name": "Pokémon Pixel Art Patch",
            "pictures": [
                "pokemon_patch.jpeg"
            ]
        },
        {
            "name": "Macreme Friendship Bracelets",
            "pictures": [
                "bracelet_1.jpeg",
                "bracelet_2.jpeg",
                "bracelet_3.jpeg"
            ]
        },
        {
            "name": "Hand Knit Sweater",
            "pictures": [
                "sweater.jpeg"
            ]
        },
        {
            "name": "Custom Phone Lockscreen",
            "pictures": [
                "lockscreen_1.JPG",
                "lockscreen_2.png",
                "lockscreen_3.png"
            ]
        }
     ];
}

export default prods;